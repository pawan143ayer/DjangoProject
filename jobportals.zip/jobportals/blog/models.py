from django.db import models
from ckeditor.fields import RichTextField

# Create your models here.
class BlogCategory(models.Model):
    name = models.CharField(max_length=40)

    def __str__(self):
        return self.name


class Blog(models.Model):
    title = models.CharField(max_length=40)
    description = RichTextField()
    tag = models.CharField(max_length=100)

    def __str__(self):
        return self.title
