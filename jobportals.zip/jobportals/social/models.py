from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Social(models.Model):
    facebook = models.CharField(max_length=30,unique=True)
    instagram= models.CharField(max_length=30,unique=True)
    twitter = models.CharField(max_length=30,unique=True)
    user  = models.ForeignKey(User,on_delete=models.CASCADE)

    def __str__(self):
        return self.facebook
