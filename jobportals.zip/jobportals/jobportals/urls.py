from django.conf.urls import url,include
from django.contrib import admin
from .import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    url(r'^admin/',admin.site.urls),
    url(r'^home/',views.home),
    url(r'^contact/',views.contact,name='contact' ),
    url(r'^login/',views.login,name='login'),
    url(r'^profile/',views.profile,name='profile'),
    url(r'^about/',views.about,name='about'),
    url(r'^dashboard/',views.dashboard,name='dashboard'),
    url(r'^professionals/',views.professionals,name='professionals'),
    url(r'^teammember/',views.teammember,name='teammember'),
    url(r'^team/',views.team,name='team'),
    url(r'^services/',views.services,name='services'),
    url(r'^right-slidebar/',views.rightslidebar,name='right-slidebar'),
    url(r'^left-slidebar/',views.leftslidebar,name='left-slidebar'),
    url(r'^fullwidth/',views.fullwidth,name='fullwidth'),
    url(r'^faqs/',views.faqs,name='faqs'),
    url(r'^404/',views.e404,name='404'),
    url(r'^post-profile/',views.postprofile,name='postprofile'),
    url(r'^post-job/',views.postjob,name='postjob'),
    url(r'^blog-fullwidth/',views.blogfullwidth,name='blogfullwidth'),
    url(r'^blogleftsliderbar/',views.blogleftsliderbar,name='blogleftsliderbar'),
    url(r'^blogrightsliderbar/',views.blogrightsliderbar,name='blogrightsliderbar'),
    url(r'^blogpost/',views.blogpost,name='blogpost'),
    url(r'^columns/',views.columns,name='columns'),
    url(r'^icons/',views.icons,name='icons'),
    url(r'^pricing/',views.pricing,name='pricing'),
    url(r'^shortcodes/',views.shortcodes,name='shortcodes'),
    url(r'^typography/',views.typography,name='typography'),

    ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
