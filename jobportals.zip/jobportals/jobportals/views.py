from django.http import HttpResponse
from django.shortcuts import render
from slider.models import Slider

def blog(request):
    return HttpResponse("<h1>this is blog page</h1>")
def contactus(request):
    return HttpResponse("<h1>this is contactus page</h1>")
def home(request):
    context={
    'slider': Slider.objects.all(),
    }
    return render(request,'index.html',context)
def contact(request):
    return render(request,'contact.html')
def login(request):
    return render(request,'login.html')
def profile(request):
    return render(request,'profile.html')
def about(request):
    return render(request,'about.html')
def dashboard(request):
    return render(request,'dashboard.html')
def professionals(request):
    return render(request,'professionals.html')
def teammember(request):
    return render(request,'teammember.html')
def team(request):
    return render(request,'team.html')
def services(request):
    return render(request,'services.html')
def rightslidebar(request):
    return render(request,'right-slidebar.html')
def leftslidebar(request):
    return render(request,'left-slidebar.html')
def fullwidth(request):
    return render(request,'fullwidth.html')
def faqs(request):
    return render(request,'faqs.html')
def e404(request):
    return render(request,'404.html')
def postprofile(request):
    return render(request,'post-profile.html')
def postjob(request):
    return render(request,'post-job.html')
def blogfullwidth(request):
    return render(request,'blog-fullwidth.html')
def blogleftsliderbar(request):
    return render(request,'blogleftsliderbar.html')
def blogrightsliderbar(request):
    return render(request,'blogrightsliderbar.html')
def blogpost(request):
    return render(request,'blogpost.html')
def columns(request):
    return render(request,'columns.html')
def icons(request):
    return render(request,'icons.html')
def pricing(request):
    return render(request,'pricing.html')
def shortcodes(request):
    return render(request,'shortcodes.html')
def typography(request):
    return render(request,'typography.html')
