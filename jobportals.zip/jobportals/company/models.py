from django.db import models
from django.contrib.auth.models import User
from employee.models import CV
from ckeditor.fields import RichTextField

# Create your models here.
class Company(models.Model):
    Company_Name = models.CharField(max_length=30,unique=True)
    Address= models.CharField(max_length=30)
    Portfolio = models.URLField(max_length=30,unique=True)
    Contact_no = models.CharField(max_length=30,unique=True)
    user  = models.ForeignKey(User,on_delete=models.CASCADE)

    def __str__(self):
        return self.Company_Name

class Vacancy(models.Model):
    Title = models.CharField(max_length=30,unique=True)
    Description= RichTextField(blank=True)
    tag= models.CharField(max_length=100,blank=True)
    Company= models.ForeignKey(Company,on_delete=models.CASCADE)

    def __str__(self):
        return self.Title


class Application(models.Model):
    cv=models.ForeignKey(CV,on_delete=models.CASCADE)
    vacancy=models.ForeignKey(Vacancy,on_delete=models.CASCADE)

    def __str__(self):
        return str(self.cv)
