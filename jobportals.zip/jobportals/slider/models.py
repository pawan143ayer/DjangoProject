from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Slider(models.Model):
    sname=models.CharField(max_length=20,default='s')
    image=models.ImageField(upload_to='slider/')

    def __str__ (self):
        return self.sname
