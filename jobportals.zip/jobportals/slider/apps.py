from django.apps import AppConfig


class SliderConfig(AppConfig):
    name = 'slider'
