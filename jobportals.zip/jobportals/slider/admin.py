from django.contrib import admin
from . models import Slider

# Register your models here.
admin.site.register(Slider)
