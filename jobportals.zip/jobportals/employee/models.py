from django.db import models
from django.contrib.auth.models import User



# Create your models here.
class Employee(models.Model):
    Name = models.CharField(max_length=30,unique=True)
    Address= models.CharField(max_length=30)
    Portfolio = models.URLField(unique=True)
    Contact = models.CharField(max_length=30,unique=True)
    user  = models.ForeignKey(User)

    def __str__(self):
        return self.Name

class Skill(models.Model):
    Skill = models.CharField(max_length=30,unique=True)
    employee = models.ForeignKey(Employee)

    def __str__(self):
        return self.Skill

class CV(models.Model):
    name=models.CharField(max_length=30)
    cv_file=models.FileField(upload_to='cv/')
    employee=models.ForeignKey(Employee,on_delete=models.CASCADE)

class Training(models.Model):
    Training_name= models.CharField(max_length=30,unique=True)
    Institute= models.CharField(max_length=30,unique=True)
    employee = models.ForeignKey(Employee)

    def __str__(self):
        return self.Training

class Degree(models.Model):
    Degree_name= models.CharField(max_length=30,unique=True)
    Institute= models.CharField(max_length=30,unique=True)
    employee = models.ForeignKey(Employee)

    def __str__(self):
        return self.Degree


class Experience(models.Model):
    Company= models.CharField(max_length=30,unique=True)
    Start_date= models.DateField(max_length=30,unique=True)
    End_date= models.DateField(max_length=30,unique=True)
    employee = models.ForeignKey(Employee)

    def __str__(self):
        return self.Experience
