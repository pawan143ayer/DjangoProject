from django.contrib import admin

# Register your models here.
from.models import Employee, Skill,Training,Experience,Degree,CV

admin.site.register(Employee)
admin.site.register(Skill)
admin.site.register(Training)
admin.site.register(Experience)
admin.site.register(Degree)
admin.site.register(CV)
